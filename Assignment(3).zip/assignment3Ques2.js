function askingAge(){
var data= prompt("Write your age ?");
if(data>=18){
  console.log("safe drive");
}
else{
  console.log("Not legal age to drive");
}}
askingAge();
