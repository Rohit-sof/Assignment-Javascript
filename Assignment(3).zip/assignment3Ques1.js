
<!DOCTYPE html>
<html>
<head>
<title>
Assignment 3 (Question 1)
</title>
</head>
<body>
<script>
var library= [
  {
   author:'Bill Gates',
   title:'The Road Ahead',
   readingStatus:true
  },
  {
   author:'Steve Jobs',
   title:'Walter Isaacson',
   readingStatus:true
  },
  {
   author:'Suzanne Collins',
   title:'Mockingjay: The Final Book Of The Hunger Games',
   readingStatus:false
  }];
console.log("Already read "+library[0].author+" by "+library[0].title);
console.log("Already read "+library[1].author+" by "+library[1].title);
console.log("You still need to read "+library[2].author+" by "+library[2].title);

</script>
</body>
</html>
