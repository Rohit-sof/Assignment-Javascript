<!DOCTYPE html>
<html>
<head>
<title>
Assignment 2 (Question 2)
</title>
</head>
<body>
<script>
const cloths= ['jacket','t-shirt'];
cloths.length=0;
  console.log(cloths[0]);
</script>
</body>
</html>
//output will be undefined because we have declared 
//arrays as value to 0 but there are two array's elements
//it means it is wrong.
