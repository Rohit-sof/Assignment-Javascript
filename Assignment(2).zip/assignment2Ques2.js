<!DOCTYPE html>
<html>
<head>
<title>
Assignment 2 (Question 2)
</title>
</head>
<body>
<script>
var num = [1,4,6,8,10];
var sum = 0;
var i =0;
for(i=0;i<num.length;i++){
  sum+=num[i];}
  console.log(sum);
  
</script>
</body>
</html>