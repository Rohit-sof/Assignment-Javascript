<html>
<head>
</head>
<body>

<script>
console.log(1 +"2"+"2");
console.log(1 + +"2"+"2");
console.log(1+ -"1"+"2");
console.log(+"1"+"1"+"2");
console.log("A"-"B"+"2");
console.log("A"-"B"+2);

</script>
</body>
</html>

Output:
122
32
02
112
NaN2
NaN