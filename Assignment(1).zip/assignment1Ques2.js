<!DOCTYPE html>
<html>
<head>
<title>
Assignment 1 (Question 2)
</title>
</head>
<body>
<script>
console.log("Your result looks like");
var marks = 56;
if(marks>90){
  console.log("Your rank is : AA");
}
else if(marks>=80){
  console.log("Your rank is : AB");
}
else if(marks>=70){
  console.log("Your rank is : BB");
}
else if(marks>=60){
  console.log("Your rank is : BC");
} 
else if(marks>=50){
  console.log("Your rank is : CC");
}
else if(marks>=40){
  console.log("Your rank is : CD");
}
else if(marks>=30){
  console.log("Your rank is : DD");
}
else if(marks<=30){
  console.log("Your rank is : FF");
}
</script>
</body>
</html>